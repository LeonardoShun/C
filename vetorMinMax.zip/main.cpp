#include "vetor.h"

int main() {
    
    int tamanho;
    cout << "Tamanho do vetor: "; cin >> tamanho;
    cout << "\n";
    int arr[tamanho];
    
    criaVetor(arr, tamanho);
    minimo(arr, tamanho);
    maximo(arr, tamanho);

    return 0;
}
